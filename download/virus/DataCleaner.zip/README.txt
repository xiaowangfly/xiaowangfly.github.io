        ||||||||_                                              _|||||||_  _||                                                                         
        || ____\|||_                  _|\                    |||__   _\_   ||                                                                         
        ||        |\\                 _|\                  _||_            ||                                                                         
        \|         |\_   _\|||\|\   \|\|||||   |||||||_    ||              |\     _|\||||     _||||||\     || ||\|||       ||||||_    || _\||         
        ||          |\   __    _||    _|\      \     ||   _||              ||    \|_    ||_   __    _||    |||_   _||    \|\    \|_   |||\            
        ||          ||          ||    _|_            \|_  _|\              ||   \|_      ||          |\    ||      |\   _|\      |\   ||\             
        ||         _|\   _|||||\||    _\_      _|\|||||_  _||              ||   |||\|||\|||   _|||||\||    ||      ||   |||||||||||   ||_             
        ||        _||   _|\     \|    _|_     ||     _|_   ||_             ||   ||           \|\     ||    ||      ||   \|_           ||_             
        ||      _|||    ||     _|\    _|\    _||     ||_    |||            ||   _||          \|     _\|    ||      ||    ||           |\_             
        \|||||||||      _|||\|\_\|     |||\\  \|\\\|||\\     _||||\|\|\_   ||    _||||\|||   _|||\||_|\    ||      ||_    ||||\|||_   ||_             
          ___              ___          ____    ___             ______              _____       ___                         _____                     
                                                                                                                                                      
                                                                                                                                                      
                                                                                                                                                      
                                                                                                                                                      



The logo at windows10 must at the 10% notepad can look!



The malware can crash your all datas,and can't to find!
Creator by XiaowangFly!
Thanks by Lichen0459 and LeoLezury!

==================================================================
Malware alert

The malware can crash your system
The MBR is modification by wipet's monoxide
You can use the command console dir at the virus path,enter "DataCleaner.exe -de" to jump the alert
The virus have 20 GDI and 1ByteBeat,the GDI payload is random.
Virus run at system screen smaller 1920*1080 have a screentest for alert
The virus double click have the two alerts,for first alert and final alert.
There alerts to attention at the system and you.
Avoid for loss.
==================================================================

The readme is about the DataCleaner trojan

Write language:Vistual Studio 2022 C++